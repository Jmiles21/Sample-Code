﻿CREATE USER [FA_NET\prgilliam] FOR LOGIN [FA_NET\prgilliam];

