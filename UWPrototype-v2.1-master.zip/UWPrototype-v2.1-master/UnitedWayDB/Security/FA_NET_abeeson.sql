﻿CREATE USER [FA_NET\abeeson] FOR LOGIN [FA_NET\abeeson];

