﻿ALTER ROLE [db_owner] ADD MEMBER [UA-NET\prgilliam];


GO
ALTER ROLE [db_owner] ADD MEMBER [FA_NET\prgilliam];


GO
ALTER ROLE [db_owner] ADD MEMBER [FA_NET\abeeson];


GO
ALTER ROLE [db_owner] ADD MEMBER [UnitedWayAppAccount];


GO
ALTER ROLE [db_owner] ADD MEMBER [UA-NET\abeeson];

