﻿CREATE USER [UA-NET\abeeson] FOR LOGIN [UA-NET\abeeson];

