﻿CREATE USER [UA-NET\prgilliam] FOR LOGIN [UA-NET\prgilliam];

