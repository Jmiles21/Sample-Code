﻿CREATE TABLE [dbo].[Test] (
    [age]   INT         NULL,
    [Fname] VARCHAR (1) NULL
);

